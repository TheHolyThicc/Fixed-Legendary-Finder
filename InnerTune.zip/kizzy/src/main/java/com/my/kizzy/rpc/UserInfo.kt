package com.my.kizzy.rpc

/**
 * Created by Zion Huang
 */
data class UserInfo(
    val username: String,
    val name: String,
)
