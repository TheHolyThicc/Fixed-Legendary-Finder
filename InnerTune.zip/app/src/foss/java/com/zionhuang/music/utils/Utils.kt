package com.zionhuang.music.utils

import com.zionhuang.music.MainActivity
import java.lang.Exception

fun reportException(throwable: Throwable) {
    throwable.printStackTrace()
}
