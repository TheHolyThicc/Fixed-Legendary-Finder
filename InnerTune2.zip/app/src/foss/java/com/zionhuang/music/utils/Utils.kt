package com.zionhuang.music.utils

import com.zionhuang.music.MainActivity
import java.lang.Exception

fun MainActivity.setupRemoteConfig() {}

fun reportException(throwable: Throwable) {
    throwable.printStackTrace()
}
